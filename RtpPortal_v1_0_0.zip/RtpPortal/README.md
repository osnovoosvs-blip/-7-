# RtpPortal

Порталы со случайной телепортацией. Игрок входит в зону — выполняется команда `rtp`
(по умолчанию из плагина RtpAuction, команда меняется в config.yml).

## Создание портала
1. Встаньте в один угол зоны: `/rtpportal pos1`
2. Встаньте в противоположный угол: `/rtpportal pos2`
3. `/rtpportal create <имя>`

Другие команды: `/rtpportal remove <имя>`, `/rtpportal list`, `/rtpportal reload`.

Права: `rtpportal.admin` (оп), `rtpportal.use` (все).
Совет: в RtpAuction поставьте `rtp.warmup-seconds: 0`, иначе телепорт отменяется, если игрок двигается.
